# Kill a Monster!

## Brief Description

This is a very small application developed in vue.js where you can battle against a monster. This app is an attempt to reverse-enginner one of the course project app created by [Maximilian Schwarzmüller](https://github.com/mschwarzmueller) in his [Vue JS 2 - The Complete Guide (incl. Vue Router & Vuex)](https://www.udemy.com/vuejs-2-the-complete-guide/). This app was developed used a basic knowledge and none previous experience of vue.js, so maybe some code is too ovewhelming for its goal and not leaner as it should be. The app development was a little bit rush (due for its goal) so code can be absolutely improved (especially in the app visual design) also there's a lack of code documentation, sorry.

## App Features

Here some feature of the app:

- If you attack the monster it will respond with its attack
- If you heal yourself monster will respond with its attack
- If you use a special attack against the monster it will receive another attack opportunity
- If monster's health is under 30HP it will heal itself

## If you want run the app locally

- Download the code
- Install the dependecies (`npm install`)
- Run `npm start` from the project root
- Enjoy!

## If you want run the app without installation

Got to the [link](http://stereotyped-measure.surge.sh/)
